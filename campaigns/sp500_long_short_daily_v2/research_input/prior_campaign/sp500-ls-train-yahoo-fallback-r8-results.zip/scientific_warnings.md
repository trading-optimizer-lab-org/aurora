# Scientific warnings

Final train result: NEGATIVE_RESULT.
Validation was not opened and observations from 2021 onward were not accessed.
The following frozen research warnings remain authoritative.

## Source: contradictions_and_negative_results.md

# Contradictions, negative results and failure modes

## Direct conclusion

The literature does not support one universally superior daily sign. The most dangerous error would be to merge contradictory mechanisms into a single retrospective story. This package preserves the contradictions as separate trials and predefines how they can fail.

| Conflict | Strongest case for A | Strongest case for B | Decision in this package |
| --- | --- | --- | --- |
| Trend continuation vs. panic rebound | Own-return continuation and technical buy/sell evidence are broad. | Momentum can crash during violent rebounds after market stress. | Keep trend and panic-reversal rules separate; report rebound-event performance and never tune a crash filter on validation. |
| Rising volatility is bearish vs. high fear predicts positive returns | VIX jumps accompany risk-off price pressure. | High variance premium or extreme fear may imply compensation/reversal. | Separate VIX change, VIX extreme, term structure and VRP; count every sign variant in multiplicity. |
| Term inversion is bearish vs. equities can rally while inverted | Curve inversion predicts recession risk at long/variable leads. | The exact equity timing is unstable and policy regimes change. | Use fixed sign as a slow state only; judge daily strategy empirically without ex-post recession timing. |
| High sentiment follows trends vs. high sentiment is contrarian | Positioning can reveal informed demand or persistent risk appetite. | Crowding/optimism can forecast lower future returns. | Trend and contrarian signs are different candidates; release lag and horizon are explicit. |
| Breadth improves confidence vs. breadth divergence can persist | Broad participation often supports healthier trends. | Narrow leadership can persist, and free historical breadth is a proxy. | Require point-in-time/proxy labels; no current-member reconstruction. |
| Latent regimes are real vs. regime labels are model artifacts | Filtered switching models can capture persistent state changes. | State count, distribution and labels are unstable; random walks can mimic phases. | Two states only, filtered probabilities only, complexity penalty, deterministic restarts. |
| Valuation predicts long-horizon returns vs. weak short-horizon timing | Present-value logic is economically strong. | Out-of-sample monthly forecasts are noisy and unstable. | Lower priority; constrained sign forecasts and equal combinations only. |
| Calendar regularities vs. publication decay/data mining | Long histories contain recurring calendar means. | Many slices create false discoveries and effects can decay. | Six predefined calendar candidates; no month/day mining. |
| Published significance vs. replication/post-publication decay | Peer-reviewed findings can be genuine in their samples. | Returns often attenuate after publication and under corrected definitions. | Evidence motivates tests; it does not bypass train/validation gates. |
| Zero costs simplify mechanism vs. make high-turnover rules unrealistic | The user explicitly requested zero costs to isolate gross signal behavior. | Shorting, opening execution and switching are not free in reality. | All calculations use exact zero; turnover and a non-binding sensitivity report are still recorded, never used for acceptance. |

## Negative evidence that changes the protocol

- **Data snooping:** the best member of a large technical-rule family is not evaluated as if it were the only rule tested. Reality Check/SPA and the full candidate count are mandatory.
- **Equity-premium forecast failures:** a model that looks plausible in-sample but does not beat simple baselines in train walk-forward is rejected before validation.
- **Post-publication attenuation:** post-2010 papers are a separate track. Their existence cannot be silently projected back to 2010.
- **Survivorship:** current S&P constituents cannot create historical breadth, correlation or sector leadership.
- **Revisions:** latest NFCI, macro and model-based index histories can leak future revisions. If no vintage/reconstruction passes, the candidate is classified as a data failure.
- **Backfilled indexes:** a calculated historical value before live dissemination is not automatically causally available.
- **Open execution:** signals measured at the close are not credited with the close price. Next-open gaps are part of realized strategy performance.

## Required negative controls

1. Random signs generated from the fixed seed, with the same open-to-open accounting.
2. Permanently long, permanently short and symmetric 200-day price/SMA benchmarks.
3. Label-permutation and circular-shift controls that preserve return autocorrelation blocks.
4. Intentionally leaked variants in test-only code to verify the causality detector catches close/open and vintage leakage; leaked variants never enter the candidate universe.
5. Duplicate-candidate injection in test fixtures to verify canonical hashing/deduplication.

## What counts as a valid negative result

A campaign is scientifically successful even when no strategy passes. The final artifact must then say `NEGATIVE_RESULT`, preserve the complete tested universe and diagnostics, and state whether failure came from economics (no robust edge), data feasibility, causal timing, multiplicity, validation degradation or a combination. It must not create a second candidate search after seeing validation.


## Final package audit additions

- Six formerly research-only ES-dependent candidates were not allowed to remain executable because their required dataset was classified `not_free`. They now use only the explicitly documented SPY overnight-gap proxy; ES remains a literature/data-inventory item, not a dependency.
- Buy-and-hold and 12-month momentum benchmarks were added because the required five-benchmark contract cannot be satisfied by always-long, always-short and SMA-200 alone.
- Bibliographic identity verification was reduced conservatively to 160 exact primary identities after correcting metadata mismatches. No numerical paper result is treated as independently replicated solely because its citation is verified.


## Source: open_questions_and_risks.md

# Open questions and risks

## Must be resolved before the full train run

| Issue | Why it matters | Required resolution | Fail-closed outcome |
| --- | --- | --- | --- |
| SPY adjusted-open reconstruction | Adjusted close does not automatically define an adjusted open, and distributions affect open-to-open return. | Reconcile raw OHLC, splits and State Street distributions with hand-calculated event tests. | Core target data ineligible. |
| Stooq/Yahoo adjustment semantics | Providers can differ around events and corrections. | Snapshot both; document tolerance and choose one canonical raw series only after reconciliation. | Technical/data failure, not performance zero. |
| Cboe term-index live/backfill dates | A historical backfill may not have been known at the historical date. | Store first dissemination date or reconstruct from causal inputs. | Exclude pre-dissemination observations/candidate history. |
| Credit/financial-condition vintages | Latest histories can include future revisions. | Use ALFRED/archived releases or reconstruct; prove release-date joins. | Candidate data ineligible. |
| Breadth archive provenance | Exchange breadth is not S&P breadth and definitions may change. | Validate source, issue definitions, calendar and missing days; label as proxy. | Breadth families rejected from runnable set. |
| SPY overnight-gap reconstruction | Raw opening gaps can be corrupted by splits/distributions or retrospective adjustment factors. | Reconstruct `SPY_TR_OPEN_t` and `SPY_TR_CLOSE_{t-1}` from raw bars plus State Street actions; hand-test every event. Paid ES data are not a dependency. | Overnight/gap family is `DATA_INELIGIBLE`. |
| Source terms and redistribution | A free download may prohibit redistribution. | Store code, URLs and hashes; do not place restricted raw data in the ZIP/artifacts. | Use retrievable manifest only. |

## Must be resolved before validation is opened

- Train merge contains every candidate or an explicit rejection row.
- Candidate code, data snapshots, environment and finalist order are frozen and hashed.
- Multiple-testing outputs complete without numerical errors.
- No unresolved data repair decision was influenced by train ranking.
- GitHub artifact containing `train_selection_freeze.json` is downloadable and hash-verified.
- Validation acknowledgment is exactly `OPEN_VALIDATION_2011_2020_ONCE`.
- Workspace scan proves no 2021+ observations, caches or precomputed features.

## Scientific risks that cannot be eliminated

1. **Transfer risk:** multi-asset futures, cross-sectional stocks or monthly horizons may not transfer to SPY next-open trading.
2. **Power:** 1993-2010 provides a limited number of independent market regimes; daily observations do not equal independent observations.
3. **Structural change:** market microstructure, index composition, monetary regimes and option markets evolved.
4. **Publication bias:** the literature overrepresents positive findings, and post-publication returns may attenuate.
5. **Proxy risk:** free VRP, breadth and cross-asset proxies are not exact institutional datasets.
6. **Zero-cost external validity:** gross results can materially overstate implementable short/reversal performance.
7. **One validation set:** 2011-2020 can adjudicate this frozen universe once, not provide unlimited model development.

## What would invalidate the final conclusion

- discovery of lookahead or use of revised final values;
- a corporate-action/open-return error;
- a candidate or benchmark calculated with different timing;
- missing candidates hidden rather than logged;
- validation opened before the train freeze;
- any access to 2021+ outcomes during this campaign;
- code or data changing between train freeze and validation;
- a reported positive result that passes only after changing an acceptance threshold.

## Deliberately unanswered by this package

The package does not claim which candidate wins, what its train/validation returns are, or whether a live implementation is profitable after real costs. Those are empirical outputs for Aurora under the frozen protocol.

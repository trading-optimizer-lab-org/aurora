# NEGATIVE_RESULT

- Candidates evaluated: 65
- Candidates rejected technically/data: 103
- Frozen finalists: 0
- Validation opened: false
- Locked observations opened: false
- Latest train observation: 2010-12-31
